import "./styles/index.css";
import "./styles/hero.css";
import anime from "../anime-list.json";
import React, { useState, useEffect } from "react";

function Hero() {
  // Initialize state with the first anime's data
  const [animeData, setAnimeData] = useState(anime[0]);
  const [activeButton, setActiveButton] = useState(null);
  const [activeBullet, setActiveBullet] = useState(1);

  // Function to handle button click
  function handleButtonClick(buttonId) {
    setActiveButton(buttonId);
  }

  // Function to handle bullet click
  function handleBulletClick(bulletId) {
    const bulletNum = bulletId - 1; // Adjust for zero-based index
    if (anime[bulletNum]) {
      setActiveBullet(bulletId); // Update bullet ID for active state
      setAnimeData(anime[bulletNum]); // Update anime data based on bullet
    }
  }

  // Log background image path for debugging
  useEffect(() => {
    console.log("Background image path:", animeData.img);
  }, [animeData.img]);

  return (
    <section className="hero-section">
      <div className="hero-main-cntr">
        <div className="img-cntr">
          <img src={animeData.img} alt="Anime background" />
        </div>
        <div className="overview-cntr">
          <span className="anime-title">{animeData.name}</span>
          <div className="cat-and-rate-cntr">
            <span className="rate">
              <i className="fa-solid fa-star"></i>
              <span className="ratings">{`${animeData.ratings}.0`}</span>
            </span>
            <span className="category">{`Category: ${animeData.category.join(
              ", "
            )}`}</span>
          </div>
          <span className="anime-desc">{animeData.description}</span>
          <div className="btn-cntr">
            <button className="watch-now">
              <i className="fa-solid fa-play"></i> Watch now!
            </button>
            <button className="heart-react">
              <i className="fa-solid fa-heart"></i>
            </button>
          </div>
        </div>
        <div className="btn-selection-cntr">
          <div className="anime-btns-cntr">
            <button
              className={`overview-btn ${
                activeButton === "overview" ? "active" : ""
              }`}
              onClick={() => handleButtonClick("overview")}
            >
              Overview
            </button>
            <button
              className={`episodes-btn ${
                activeButton === "episodes" ? "active" : ""
              }`}
              onClick={() => handleButtonClick("episodes")}
            >
              Episodes
            </button>
            <button
              className={`details-btn ${
                activeButton === "details" ? "active" : ""
              }`}
              onClick={() => handleButtonClick("details")}
            >
              Details
            </button>
          </div>
          <div className="bullet-btns-cntr">
            <button
              className={`bullet-btn ${activeBullet === 1 ? "active" : ""}`}
              onClick={() => handleBulletClick(1)}
            ></button>
            <button
              className={`bullet-btn ${activeBullet === 2 ? "active" : ""}`}
              onClick={() => handleBulletClick(2)}
            ></button>
            <button
              className={`bullet-btn ${activeBullet === 3 ? "active" : ""}`}
              onClick={() => handleBulletClick(3)}
            ></button>
            <button
              className={`bullet-btn ${activeBullet === 4 ? "active" : ""}`}
              onClick={() => handleBulletClick(4)}
            ></button>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Hero;
